(() => {
  "use strict";

  const DEFAULT_SETTINGS = {
    enabled: true,
    keywords: "xiao8",
    keywordItems: [{ text: "xiao8", enabled: true }],
    regexMode: false,
    caseInsensitive: true,
    disableImagePreview: false,
    blacklistUrls: "viewthread\nthread-\nread.php?tid=\npost.php\n/p/"
  };

  const HIDDEN_ATTR = "data-fkh-hidden";
  const PREVIEW_HIDDEN_ATTR = "data-fkh-preview-hidden";
  const HTML_PREVIEW_CLASS = "fkh-disable-image-preview";
  const STYLE_ID = "fkh-style";

  const ROW_SELECTOR = [
    "tbody", "tr", "li", "article", ".thread", ".topic", ".post-row",
    ".thread-row", ".topic-row", ".forum_thread", ".list-item",
    "[class*='thread' i]", "[class*='topic' i]",
    "[class*='post-row' i]", "[class*='thread-row' i]", "[class*='topic-row' i]"
  ].join(",");

  let settings = { ...DEFAULT_SETTINGS };
  let textMatchers = [];     
  let selectorMatchers = []; 
  let scanTimer = null;
  let previewTimer = null;
  let observer = null;
  let lastImageHoverAt = 0;
  let isBlacklistedPage = false; 

  function checkBlacklist() {
    if (!settings.blacklistUrls) return false;
    const url = window.location.href;
    const list = settings.blacklistUrls.split(/\r?\n|,/).map(s => s.trim()).filter(Boolean);
    return list.some(path => url.includes(path));
  }

  function escapeRegExp(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function getActiveKeywordLines() {
    if (Array.isArray(settings.keywordItems)) {
      return settings.keywordItems
        .filter(item => item && item.enabled !== false)
        .map(item => String(item.text || "").trim())
        .filter(Boolean);
    }
    return String(settings.keywords || "").split(/\r?\n|[,，;；]/).map(line => line.trim()).filter(line => line);
  }

  function buildMatchers() {
    const lines = getActiveKeywordLines();
    const flags = settings.caseInsensitive ? "i" : "";
    const nextRegex = [];
    const nextSelectors = [];

    for (const line of lines) {
      // 增强：支持更标准的 CSS 选择器写法 (如 ., #, [, 或 css: 开头)
      if (line.startsWith("css:")) {
        nextSelectors.push(line.substring(4).trim());
      } else if (line.startsWith(".") || line.startsWith("#") || line.startsWith("[")) {
        nextSelectors.push(line);
      } else {
        try {
          if (settings.regexMode) {
            nextRegex.push(new RegExp(line, flags));
          } else {
            nextRegex.push(new RegExp(escapeRegExp(line), flags));
          }
        } catch (err) {
          console.warn("[Forum Keyword Hider] Invalid regex:", line);
        }
      }
    }

    textMatchers = nextRegex;
    selectorMatchers = nextSelectors;
  }

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const css = `
      [${HIDDEN_ATTR}] {
        display: none !important;
        height: 0 !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
      }

      html.${HTML_PREVIEW_CLASS} img:hover,
      html.${HTML_PREVIEW_CLASS} a:hover img,
      html.${HTML_PREVIEW_CLASS} [style*="background-image"]:hover {
        transform: none !important;
        scale: 1 !important;
        transition: none !important;
        animation: none !important;
      }

      [${PREVIEW_HIDDEN_ATTR}] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
    `;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = css;
    (document.documentElement || document.head || document).appendChild(style);
  }

  function applyPreviewClass() {
    if (!document.documentElement) return;
    document.documentElement.classList.toggle(HTML_PREVIEW_CLASS, !!settings.disableImagePreview);
  }

  function getDirectTrCount(tbody) {
    if (!tbody || tbody.tagName !== "TBODY") return 0;
    return Array.from(tbody.children).filter(child => child.tagName === "TR").length;
  }

  function isLargeContainer(el) {
    const tag = el.tagName;
    if (tag === "HTML" || tag === "BODY" || tag === "MAIN") return true;
    const text = (el.innerText || el.textContent || "").trim();
    if (text.length > 6000) return true;
    if (tag === "TBODY" && getDirectTrCount(el) > 4) return true;
    return false;
  }

  function resolveHideTarget(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return null;
    if (el.tagName === "TBODY") {
      return getDirectTrCount(el) <= 4 ? el : null;
    }
    if (el.tagName === "TR") {
      const tbody = el.closest("tbody");
      const directRows = getDirectTrCount(tbody);
      if (tbody && directRows > 0 && directRows <= 4) return tbody;
      return el;
    }
    return el.closest("li, article, .thread, .topic, .post-row, .thread-row, .topic-row, tr") || el;
  }

  function hideElement(el) {
    const target = resolveHideTarget(el);
    if (!target) return;

    target.setAttribute(HIDDEN_ATTR, "1");
    target.style.setProperty("display", "none", "important");
    target.style.setProperty("height", "0", "important");
    target.style.setProperty("min-height", "0", "important");
    target.style.setProperty("margin", "0", "important");
    target.style.setProperty("padding", "0", "important");
    target.style.setProperty("border", "0", "important");
  }

  function scanPage() {
    scanTimer = null;
    if (!settings.enabled || isBlacklistedPage || !document.documentElement) return;

    // 1. 处理 CSS 选择器匹配 (原生高性能匹配)
    if (selectorMatchers.length > 0) {
      try {
        const selectorStr = selectorMatchers.join(",");
        document.querySelectorAll(selectorStr).forEach(el => {
          if (!el.hasAttribute(HIDDEN_ATTR)) hideElement(el);
        });
      } catch (err) {
        console.warn("[Forum Keyword Hider] Invalid CSS selectors:", selectorMatchers);
      }
    }

    // 2. 处理文本与 HTML 源码的正则匹配
    if (textMatchers.length > 0) {
      let candidates = [];
      try {
        candidates = Array.from(document.querySelectorAll(ROW_SELECTOR));
      } catch (err) { return; }

      for (const el of candidates) {
        if (el.hasAttribute(HIDDEN_ATTR) || el.closest(`[${HIDDEN_ATTR}]`)) continue;
        if (isLargeContainer(el)) continue;

        const text = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
        // 【核心修改点】获取元素的 HTML 源码，用于正则匹配
        const htmlStr = el.outerHTML || "";

        if (!text && !htmlStr) continue;

        // 如果正则匹配到了文字 OR 匹配到了元素的 HTML 源码，则隐藏
        if (textMatchers.some(re => re.test(text) || re.test(htmlStr))) {
          hideElement(el);
        }
      }
    }
  }

  function scheduleScan(delay = 120) {
    if (scanTimer) return;
    scanTimer = window.setTimeout(scanPage, delay);
  }

  function resetHiddenRows() {
    document.querySelectorAll(`[${HIDDEN_ATTR}]`).forEach(el => {
      el.removeAttribute(HIDDEN_ATTR);
      el.style.removeProperty("display");
      el.style.removeProperty("height");
      el.style.removeProperty("min-height");
      el.style.removeProperty("margin");
      el.style.removeProperty("padding");
      el.style.removeProperty("border");
    });
  }

  function isImageHoverTarget(target) {
    const el = target && target.nodeType === Node.ELEMENT_NODE ? target : target?.parentElement;
    if (!el || !el.closest) return false;
    if (el.closest("img")) return true;
    const link = el.closest("a");
    if (link && link.querySelector && link.querySelector("img")) return true;
    if (el.closest("[style*='background-image']")) return true;
    const imageLike = el.closest("[class*='thumb' i], [class*='thumbnail' i], [class*='preview' i], [class*='image' i], [class*='photo' i], [class*='pic' i]");
    return !!(imageLike && imageLike.querySelector && imageLike.querySelector("img"));
  }

  function blockImagePreviewEvent(event) {
    if (!settings.disableImagePreview) return;
    if (!isImageHoverTarget(event.target)) return;
    lastImageHoverAt = Date.now();
    event.stopImmediatePropagation();
    scheduleHideLikelyPreviewOverlays(0);
  }

  function isLikelyPreviewOverlay(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
    if (el.hasAttribute(PREVIEW_HIDDEN_ATTR)) return false;
    if (!el.querySelector || !el.querySelector("img")) return false;
    if (el.querySelector("input, textarea, select")) return false;

    const imgCount = el.querySelectorAll("img").length;
    if (imgCount > 4) return false;

    const rect = el.getBoundingClientRect();
    if (rect.width < 20 || rect.height < 20) return false;

    const cs = window.getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || Number(cs.opacity) === 0) return false;

    const zIndex = Number.parseInt(cs.zIndex, 10);
    const inlineStyle = el.getAttribute("style") || "";

    const isFloating =
      cs.position === "fixed" ||
      cs.position === "absolute" ||
      (Number.isFinite(zIndex) && zIndex >= 10) ||
      (/left\s*:\s*[-\d.]+px/i.test(inlineStyle) && /top\s*:\s*[-\d.]+px/i.test(inlineStyle));

    if (!isFloating) return false;

    const text = (el.innerText || el.textContent || "").trim();
    if (text.length > 500) return false;

    return true;
  }

  function hideLikelyPreviewOverlays() {
    previewTimer = null;
    if (!settings.disableImagePreview) return;
    if (Date.now() - lastImageHoverAt > 2500) return;
    const nodes = document.querySelectorAll("body div, body span, body section, body aside, body table");
    for (const el of nodes) {
      if (!isLikelyPreviewOverlay(el)) continue;
      el.setAttribute(PREVIEW_HIDDEN_ATTR, "1");
      el.style.setProperty("display", "none", "important");
      el.style.setProperty("visibility", "hidden", "important");
      el.style.setProperty("opacity", "0", "important");
      el.style.setProperty("pointer-events", "none", "important");
    }
  }

  function scheduleHideLikelyPreviewOverlays(delay = 80) {
    if (previewTimer) return;
    previewTimer = window.setTimeout(hideLikelyPreviewOverlays, delay);
  }

  function installImagePreviewBlocker() {
    const events = ["mouseover", "mouseenter", "mousemove", "pointerover", "pointerenter", "pointermove"];
    for (const type of events) {
      document.addEventListener(type, blockImagePreviewEvent, true);
    }
  }

  function startObserver() {
    if (observer || !document.documentElement) return;
    observer = new MutationObserver(() => {
      if (settings.enabled && !isBlacklistedPage) scheduleScan();
      if (settings.disableImagePreview && Date.now() - lastImageHoverAt < 2500) {
        scheduleHideLikelyPreviewOverlays();
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["style", "class"]
    });
  }

  function loadSettingsAndRun() {
    chrome.storage.sync.get(DEFAULT_SETTINGS, saved => {
      settings = { ...DEFAULT_SETTINGS, ...saved };
      isBlacklistedPage = checkBlacklist();

      buildMatchers();
      injectStyle();
      applyPreviewClass();
      startObserver();
      
      if (!isBlacklistedPage) {
        scheduleScan(0);
      }
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "sync") return;
    const next = { ...settings };
    for (const [key, value] of Object.entries(changes)) {
      next[key] = value.newValue;
    }
    settings = { ...DEFAULT_SETTINGS, ...next };

    isBlacklistedPage = checkBlacklist();
    buildMatchers();
    injectStyle();
    applyPreviewClass();
    resetHiddenRows();
    
    if (!isBlacklistedPage) {
      scheduleScan(0);
    }
  });

  installImagePreviewBlocker();

  if (document.documentElement) {
    loadSettingsAndRun();
  } else {
    document.addEventListener("DOMContentLoaded", loadSettingsAndRun, { once: true });
  }
})();
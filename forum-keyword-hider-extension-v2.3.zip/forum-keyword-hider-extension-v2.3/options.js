(() => {
  "use strict";

  const DEFAULT_SETTINGS = {
    enabled: true,
    keywords: "xiao8",
    keywordItems: [{ text: "xiao8", enabled: true }],
    regexMode: false,
    caseInsensitive: true,
    disableImagePreview: false
  };

  const $ = id => document.getElementById(id);

  const els = {
    enabled: $("enabled"),
    keywordList: $("keywordList"),
    keywordTemplate: $("keywordRowTemplate"),
    addKeyword: $("addKeyword"),
    regexMode: $("regexMode"),
    caseInsensitive: $("caseInsensitive"),
    disableImagePreview: $("disableImagePreview"),
    status: $("status")
  };

  let isLoading = true;
  let saveTimer = null;
  let statusTimer = null;

  function parseKeywordLines(text) {
    return String(text || "")
      .split(/\r?\n|[,，;；]/)
      .map(line => line.trim())
      .filter(line => line && !line.startsWith("#"));
  }

  function normalizeKeywordItems(settings) {
    if (Array.isArray(settings.keywordItems) && settings.keywordItems.length) {
      return settings.keywordItems
        .map(item => ({
          text: String(item?.text || "").trim(),
          enabled: item?.enabled !== false
        }))
        .filter(item => item.text);
    }

    return parseKeywordLines(settings.keywords).map(text => ({
      text,
      enabled: true
    }));
  }

  function createKeywordRow(item = { text: "", enabled: true }) {
    const fragment = els.keywordTemplate.content.cloneNode(true);
    const row = fragment.querySelector(".keyword-row");
    const enabled = fragment.querySelector(".keyword-enabled");
    const input = fragment.querySelector(".keyword-text");
    const del = fragment.querySelector(".keyword-delete");

    enabled.checked = item.enabled !== false;
    input.value = item.text || "";

    enabled.addEventListener("change", () => saveNow());

    input.addEventListener("input", () => scheduleSave());
    input.addEventListener("blur", () => saveNow());
    input.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        saveNow();
        addKeywordRow({ text: "", enabled: true }, true);
      }
    });

    del.addEventListener("click", () => {
      row.remove();
      ensureAtLeastOneRow();
      saveNow();
    });

    els.keywordList.appendChild(fragment);
  }

  function addKeywordRow(item, focus = false) {
    createKeywordRow(item);
    if (focus) {
      const rows = els.keywordList.querySelectorAll(".keyword-row");
      const lastInput = rows[rows.length - 1]?.querySelector(".keyword-text");
      lastInput?.focus();
    }
  }

  function ensureAtLeastOneRow() {
    if (!els.keywordList.querySelector(".keyword-row")) {
      addKeywordRow({ text: "", enabled: true });
    }
  }

  function collectKeywordItems() {
    return Array.from(els.keywordList.querySelectorAll(".keyword-row"))
      .map(row => ({
        text: row.querySelector(".keyword-text").value.trim(),
        enabled: row.querySelector(".keyword-enabled").checked
      }))
      .filter(item => item.text);
  }

  function validateRegexItems(items, caseInsensitive) {
    const flags = caseInsensitive ? "i" : "";
    const invalid = [];

    for (const item of items) {
      if (item.enabled === false) continue;
      try {
        new RegExp(item.text, flags);
      } catch (err) {
        invalid.push(`${item.text}  →  ${err.message}`);
      }
    }

    return invalid;
  }

  function setStatus(message, isError = false, autoClear = true) {
    window.clearTimeout(statusTimer);
    els.status.textContent = message;
    els.status.classList.toggle("error", isError);

    if (autoClear && message && !isError) {
      statusTimer = window.setTimeout(() => {
        els.status.textContent = "";
      }, 1400);
    }
  }

  function renderKeywordItems(items) {
    els.keywordList.textContent = "";
    for (const item of items) addKeywordRow(item);
    ensureAtLeastOneRow();
  }

  function getCurrentSettings() {
    const keywordItems = collectKeywordItems();
    return {
      enabled: els.enabled.checked,
      keywords: keywordItems.map(item => item.text).join("\n"),
      keywordItems,
      regexMode: els.regexMode.checked,
      caseInsensitive: els.caseInsensitive.checked,
      disableImagePreview: els.disableImagePreview.checked
    };
  }

  function saveNow() {
    if (isLoading) return;

    window.clearTimeout(saveTimer);
    const settings = getCurrentSettings();

    let warning = "";
    if (settings.regexMode) {
      const invalid = validateRegexItems(settings.keywordItems, settings.caseInsensitive);
      if (invalid.length) {
        warning = `以下已勾选的正则无效，页面里会自动忽略：\n${invalid.join("\n")}`;
      }
    }

    chrome.storage.sync.set(settings, () => {
      if (chrome.runtime.lastError) {
        setStatus(`自动保存失败：${chrome.runtime.lastError.message}`, true, false);
        return;
      }

      if (warning) {
        setStatus(`已自动保存，但有正则错误。\n${warning}`, true, false);
      } else {
        setStatus("已自动生效", false);
      }
    });
  }

  function scheduleSave() {
    if (isLoading) return;
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(saveNow, 300);
  }

  function load() {
    chrome.storage.sync.get(DEFAULT_SETTINGS, settings => {
      isLoading = true;
      els.enabled.checked = !!settings.enabled;
      els.regexMode.checked = !!settings.regexMode;
      els.caseInsensitive.checked = settings.caseInsensitive !== false;
      els.disableImagePreview.checked = !!settings.disableImagePreview;
      renderKeywordItems(normalizeKeywordItems(settings));
      isLoading = false;
      setStatus("");
    });
  }

  els.addKeyword.addEventListener("click", () => addKeywordRow({ text: "", enabled: true }, true));

  [
    els.enabled,
    els.regexMode,
    els.caseInsensitive,
    els.disableImagePreview
  ].forEach(el => el.addEventListener("change", () => saveNow()));

  document.addEventListener("DOMContentLoaded", load);
  load();
})();
